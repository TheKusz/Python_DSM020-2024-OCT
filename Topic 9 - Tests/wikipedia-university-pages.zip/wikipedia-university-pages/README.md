# Wikipedia University Dataset

This is a dataset that was gathered from Wikipedia. 

Here is a link to the license for this material:

https://creativecommons.org/licenses/by-sa/3.0/


