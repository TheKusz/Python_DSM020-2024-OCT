Wikipedia content is licensed under the Creative Commons Share-alike liencse:

https://en.wikipedia.org/wiki/Wikipedia:CCBYSA
https://creativecommons.org/licenses/by-sa/3.0/



